// var baseUrl = window.location.protocol + "//" + window.location.host;

var currentURL = window.location.href;

var originalURL = currentURL
var substringToRemove = "config-app/home/config.html";

var baseUrl = originalURL.replace(substringToRemove, "");
baseUrl = baseUrl.replace(/\/+$/, ''); // Remove trailing slashes

console.log("Base URL ", baseUrl);
const apiUrl = `${baseUrl}/api/auth/GetUserList`;


const apiUrl2 = `${baseUrl}/api/auth/GetSoftwareList`;
const apiUrl3 = `${baseUrl}/api/auth/GetConfig`;
const apiUrl4 = `${baseUrl}/api/auth/UpdateConfig`;

$(document).ready(function () {
  if (checkAndRemoveExpiredTokenFromCookie()) {
    // window.location.href = `${baseUrl}/config-app/login/index.html`;
    // return
  }

  const headersToSend = {
    XApiKey:
      "PG2mVi3Ah7XMMRJQLvTNJga8rh0YSJqGSXpoVFZsprPAss0xzcupa7v6Lf9Qij0EeflNmSBSB0NmEnhfk69KiKb0veG22j6l2YGtONvm9uTDeVlZ97QqNJ6pvgQ2EOKk",
    "Content-Type": "application/json"
  };
  const token = getTokenFromCookie();
  console.log('token', token);

  loadUsers(apiUrl, headersToSend);
  loadSoftwares(apiUrl2, headersToSend);

  $("#getConfigBtn").click(function (e) {
    // validation
    loadConfig(apiUrl3, headersToSend);
    e.preventDefault();
  });

  $("#saveBtn").click(function (e) {
    const obj = {};

    $("#tbody tr").each(function (index) {
      const key = $(this).find("input[name='key']").val();
      const value = $(this).find("input[name='value']").val();
      obj[key] = value;
    });

    const jsonString = JSON.stringify(obj, (key, value) => {
      return typeof value === "string" ? value.replace(/"/g, '\\"') : value;
    });

    console.log(jsonString);

    var selectedApp = $("#selApp").val();
    var selectedUser = $("#selUser").val();
    var versionCode = $("#inputVersionCode").val();

    console.log(selectedApp, selectedUser, versionCode)

    const dataToSend = {
      AppShortName: selectedApp,
      UserId: selectedUser,
      VersionCode: versionCode,
      Config_JSON: jsonString,
    };

    saveConfig(apiUrl4, headersToSend, dataToSend);

    e.preventDefault();
  });

  $("#logoutBtn").click(function (e) {
    e.preventDefault();
    document.cookie =
      "AccessToken=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    window.location.href = `${baseUrl}/config-app/login/index.html`;
  });
});

function saveConfig(url, headersToSend, dataToSend) {
  return fetch(url, {
    method: "POST",
    headers: headersToSend,
    body: JSON.stringify(dataToSend),
  })
    .then((response) => {
      console.log(response);
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      console.log("save config", data);
      $(".toast-header").html("Done!");
      $(".toast-body").html("Saved to DB");
      $(".toast").toast("show");

      return data;
    })
    .catch((error) => {
      console.error("Error occurred: ", error);
      throw error; // Propagate the error further, if needed
    });
}

function getConfig(url, headersToSend, dataToSend) {
  return fetch(url, {
    method: "POST",
    headers: headersToSend,
    body: JSON.stringify(dataToSend),
  })
    .then((response) => {
      console.log(response);
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      $(".toast-header").html("Done!");
      $(".toast-body").html("Fetched Config from DB");
      $(".toast").toast("show");

      let htmlStr = "";

      Object.keys(data).forEach((key, idx) => {
        const value = data[key];
        // rowIdx++;
        let curRow = `
          <tr id="R${idx}">
            <td class="text-center"> 
              <input name="key" type="text" value="${key}" >
            </td>
            <td class="text-center">
              <input name="value" type="text" value="${value}" >
            </td >
            <td class="text-center">
            <button class="btn btn-danger remove" type="button">Remove</button>
            </td>
          </tr>
        `;
        htmlStr += curRow;
      });
      return htmlStr;
    })
    .catch((error) => {
      console.error("Error occurred: ", error);
      throw error; // Propagate the error further, if needed
    });
}
async function loadConfig(url, headersToSend) {
  try {

    var selectedApp = $("#selApp").val();
    var selectedUser = $("#selUser").val();
    var versionCode = $("#inputVersionCode").val();

    console.log(selectedApp, selectedUser, versionCode);

    const dataToSend = {
      AppShortName: selectedApp,
      UserId: selectedUser,
      VersionCode: versionCode
    };
    const htmlStr = await getConfig(url, headersToSend, dataToSend);
    const parentElement = document.querySelector("#tbody");

    while (parentElement.firstChild) {
      parentElement.removeChild(parentElement.firstChild);
    }

    $("#tbody").append(htmlStr);
    console.log("Config loaded successfully!");
  } catch (error) {
    console.log("Config load error ", error);
    // $("#result").text("Error occurred: " + JSON.stringify(error));
  }
}
function getUsers(url, headersToSend) {
  return fetch(url, {
    method: "GET",
    headers: headersToSend,
    contentType: "application/json",
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      let htmlStr = "";
      for (let i = 0; i < data.length; i++) {
        let curRow = `<option data-tokens="${i + 1}">${
          data[i]["UserName"]
        }</option>`;
        htmlStr += curRow;
      }
      return htmlStr;
    })
    .catch((error) => {
      console.error("Error occurred: ", error);
      throw error; // Propagate the error further, if needed
    });
}

async function loadUsers(url, headersToSend) {
  try {
    const htmlStr = await getUsers(url, headersToSend);
    $("#selUser").append(htmlStr);
    console.log("Users loaded successfully!");
  } catch (error) {
    $("#result").text("Error occurred: " + JSON.stringify(error));
  }
}

function getSoftwares(url, headersToSend) {
  return fetch(url, {
    method: "GET",
    headers: headersToSend,
    contentType: "application/json",
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      let htmlStr = "";
      for (let i = 0; i < data.length; i++) {
        let curRow = `<option data-tokens="${i + 1}">${
          data[i].ApplicationName
        }</option>`;
        htmlStr += curRow;
      }
      return htmlStr;
    })
    .catch((error) => {
      console.error("Error occurred: ", error);
      throw error; // Propagate the error further, if needed
    });
}

async function loadSoftwares(url, headersToSend) {
  try {
    const htmlStr = await getSoftwares(url, headersToSend);
    $("#selApp").append(htmlStr);
    console.log("Software list loaded successfully!");
  } catch (error) {
    $("#result").text("Error occurred: " + JSON.stringify(error));
  }
}

function getTokenFromCookie() {
  const cookieName = "AccessToken" + "=";
  const cookies = document.cookie.split(";");

  for (let i = 0; i < cookies.length; i++) {
    let cookie = cookies[i].trim();
    if (cookie.indexOf(cookieName) === 0) {
      return decodeURIComponent(
        cookie.substring(cookieName.length, cookie.length)
      );
    }
  }

  return null; // Token not found in cookies
}

function checkAndRemoveExpiredTokenFromCookie() {
  console.log("test 1");
  const token = getTokenFromCookie();
  console.log("test 2");
  if (token) {
    const tokenExpirationDate = new Date(getJwtExpirationTime(token)); // Get the expiration date from the token (assuming the token contains this information)
    const currentDate = new Date();

    if (currentDate > tokenExpirationDate) {
      // Token has expired, remove it from the cookie
      document.cookie =
        "AccessToken=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
      return true; // expired
      console.log("test 3");
    }
    return false; //not expired
    console.log("test 4");
  }
  console.log("test ");
  return true; // not present = expired
}

function getJwtExpirationTime(jwtToken) {
  // Split the JWT token into its three parts: header, payload, and signature
  const [header, payload, signature] = jwtToken.split(".");

  // Decode the payload using base64 decoding
  const decodedPayload = JSON.parse(atob(payload));

  // Get the expiration time (exp) from the decoded payload
  const expirationTime = decodedPayload.exp;

  // Convert the expiration time from seconds to milliseconds (JavaScript uses milliseconds for timestamps)
  const expirationTimeMilliseconds = expirationTime * 1000;

  // Get the current timestamp in milliseconds
  const currentTimestamp = Date.now();

  // Calculate the remaining time until the token expires
  const timeUntilExpiration = expirationTimeMilliseconds - currentTimestamp;

  // Return the expiration time in milliseconds
  return timeUntilExpiration;
}
