﻿// var baseUrl = window.location.protocol + "//" + window.location.host;
// console.log("Base URL ", baseUrl);

var currentURL = window.location.href;

var originalURL = currentURL;
var substringToRemove = "/config-app/login/index.html";

var baseUrl = originalURL.replace(substringToRemove, "");
baseUrl = baseUrl.replace(/\/+$/, ''); // Remove trailing slashes


console.log("Base URL ", baseUrl);

$(document).ready(function () {
  $("#submitBtn").click(function (e) {
    const email = $("#email").val();

    const password = $("#password").val();

    if (email.value == "" || password.value == "") {
      alert("Please input your credentials");
      return;
    }

    configLoginHandler(email, password);

    e.preventDefault();
  });
});

function configLoginHandler(UserName, Password) {
  // URL for the POST request
  const url = `${baseUrl}/api/auth/login`;

  // Data to be sent in the request body
  const dataToSend = {
    UserName,
    Password,
  };

  // Headers to be included in the request
  const headersToSend = {
    XApiKey:
      "PG2mVi3Ah7XMMRJQLvTNJga8rh0YSJqGSXpoVFZsprPAss0xzcupa7v6Lf9Qij0EeflNmSBSB0NmEnhfk69KiKb0veG22j6l2YGtONvm9uTDeVlZ97QqNJ6pvgQ2EOKk",
  };

  // Create a promise for the AJAX request
  const ajaxPromise = new Promise((resolve, reject) => {
    // Sending the AJAX POST request
    $.ajax({
      url: url,
      type: "POST",
      headers: headersToSend,
      data: JSON.stringify(dataToSend),
      contentType: "application/json",
      success: resolve, // Resolve the promise with the response
      error: reject, // Reject the promise with the error
    });
  });

  // After the AJAX request is successful
  ajaxPromise
    .then(function (response) {
      // Success callback, handle the response here
      const jsonString = JSON.stringify(response);
      const token = response["AccessToken"];
      console.log("Access token is " + token);
      console.log(response);

      // TODO: 1 save token to cookie with expiration time
      setTokenToCookie(token, 1);

      $("#result").text(JSON.stringify(response));

      // TODO: 2 Redirect to config page ( dynamic row page : Edit and Update option later )
      // TODO: 3 If token expired then go back to login page

      // TODO: Hard coded BASE URL to be removed
      
      window.location.href = `${baseUrl}/config-app/home/config.html`;
    })
    .catch(function (error) {
      // Error callback, handle errors here
      $("#result").text("Error occurred: " + JSON.stringify(error));
    });
}

function setTokenToCookie(token, expirationDays) {
  const date = new Date();
  date.setTime(date.getTime() + expirationDays * 24 * 60 * 60 * 1000); // Set expiration time

  const cookieValue =
    encodeURIComponent(token) + "; expires=" + date.toUTCString() + "; path=/";
  document.cookie = "AccessToken=" + cookieValue;
}

function getTokenFromCookie() {
  const cookieName = "AccessToken" + "=";
  const cookies = document.cookie.split(";");

  for (let i = 0; i < cookies.length; i++) {
    let cookie = cookies[i].trim();
    if (cookie.indexOf(cookieName) === 0) {
      return decodeURIComponent(
        cookie.substring(cookieName.length, cookie.length)
      );
    }
  }

  return null; // Token not found in cookies
}

function checkAndRemoveExpiredTokenFromCookie() {
  const token = getTokenFromCookie();
  if (token) {
    const tokenExpirationDate = new Date(getJwtExpirationTime(jwtToken)); // Get the expiration date from the token (assuming the token contains this information)
    const currentDate = new Date();

    if (currentDate > tokenExpirationDate) {
      // Token has expired, remove it from the cookie
      document.cookie =
        "AccessToken=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
      return true; // expired
    }
    return false; //not expired
  }
  return true; // not present = expired
}

function getJwtExpirationTime(jwtToken) {
  // Split the JWT token into its three parts: header, payload, and signature
  const [header, payload, signature] = jwtToken.split(".");

  // Decode the payload using base64 decoding
  const decodedPayload = JSON.parse(atob(payload));

  // Get the expiration time (exp) from the decoded payload
  const expirationTime = decodedPayload.exp;

  // Convert the expiration time from seconds to milliseconds (JavaScript uses milliseconds for timestamps)
  const expirationTimeMilliseconds = expirationTime * 1000;

  // Get the current timestamp in milliseconds
  const currentTimestamp = Date.now();

  // Calculate the remaining time until the token expires
  const timeUntilExpiration = expirationTimeMilliseconds - currentTimestamp;

  // Return the expiration time in milliseconds
  return timeUntilExpiration;
}

// Example usage:
// const jwtToken =
//   "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkRlZmF1bHQgVXNlciIsImlhdCI6MTYyOTk1MjQ0OSwiZXhwIjoxNjI5OTUyNTA5fQ.T1pU11Uw-8Xs1rjqd21UyQG6rSe-9BCgb6cQLk3pSk4";
// const expirationTime = getJwtExpirationTime(jwtToken);

// console.log(`Token will expire in ${expirationTime} milliseconds.`);
